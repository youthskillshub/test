// Programs page - All skills training and entrepreneurship programs
// Will include:
// - Page hero/header
// - Program categories/filters
// - Program cards with:
//   - Program name and description
//   - Duration and schedule
//   - Target age group
//   - Skills learned
//   - Application/enrollment button
// - Success stories from program graduates
// - FAQ section about programs

export default function Programs() {
  return (
    <div>
      {/* Programs content will be added here */}
    </div>
  );
}
